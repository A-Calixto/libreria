-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 15-10-2022 a las 01:10:43
-- Versión del servidor: 10.4.19-MariaDB
-- Versión de PHP: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_libreria_calixto`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bi_categorias`
--

CREATE TABLE `bi_categorias` (
  `idcategoria` int(11) NOT NULL,
  `nombre_categoria` text DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `bi_categorias`
--

INSERT INTO `bi_categorias` (`idcategoria`, `nombre_categoria`, `descripcion`, `fecha`) VALUES
(1, 'Terror', 'historias de terror en la vida cotidiana', '2022-10-13 22:40:28'),
(2, 'comedia', 'pelicular para morirse de risa todo el diaaaaaaa', '2022-10-14 16:50:07');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bi_libros`
--

CREATE TABLE `bi_libros` (
  `idlibro` int(11) NOT NULL,
  `portada` text DEFAULT NULL,
  `nombre` text DEFAULT NULL,
  `autor` text DEFAULT NULL,
  `editorial` text DEFAULT NULL,
  `sinopsis` text DEFAULT NULL,
  `idcategoria` int(11) DEFAULT NULL,
  `ano` int(11) DEFAULT NULL,
  `pais` text DEFAULT NULL,
  `idioma` text DEFAULT NULL,
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp(),
  `estatus` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `bi_libros`
--

INSERT INTO `bi_libros` (`idlibro`, `portada`, `nombre`, `autor`, `editorial`, `sinopsis`, `idcategoria`, `ano`, `pais`, `idioma`, `fecha_alta`, `estatus`) VALUES
(1, NULL, 'el diario de ana ', 'alejandro', 'Editorial desconocida', 'trata de una princesa encantada', 2, 2028, NULL, NULL, '2022-10-14 18:00:20', 1),
(2, NULL, 'El diario de una pasion', 'alejandro calixto', 'cualquiera', 'eblblblblbbl ffveverv', 2, 2025, NULL, NULL, '2022-10-14 18:03:35', 1),
(3, NULL, 'fefefe', 'erfrerfe', 'erfeferferf', 'fefefefeferfe', 2, 2024, NULL, NULL, '2022-10-14 18:09:30', 1),
(4, NULL, 'fefefe', 'erfrerfe', 'erfeferferf', 'fefefefeferfe', 2, 2024, NULL, NULL, '2022-10-14 18:09:53', 1),
(5, NULL, 'prueba', 'vicente del bosque', 'Editorial marques', 'desconocida', 1, 2020, NULL, NULL, '2022-10-14 18:12:09', 1),
(6, NULL, 'prueba', 'test', 'test', 'test', 1, 2024, NULL, NULL, '2022-10-14 18:12:09', 1),
(7, 'portada_7.jpg', 'prueba', 'test', 'test', 'test', 1, 2024, NULL, NULL, '2022-10-14 18:13:06', 1),
(8, 'portada_8.jpg', 'libro bueno', 'otro autor', 'ewvwvew', 'vwverve', 2, 2024, NULL, NULL, '2022-10-14 18:15:37', 1),
(9, 'portada_9.png', 'nombre', 'autor', 'editorial', 'sinopsis', 2, 2025, NULL, NULL, '2022-10-14 20:05:09', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `idusaurio` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellidos` varchar(50) DEFAULT NULL,
  `correo` varchar(30) DEFAULT NULL,
  `contrasena` text DEFAULT NULL,
  `telefono` varchar(16) DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `sexo` varchar(20) DEFAULT NULL,
  `fecha_nacimiento` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_alta` timestamp NOT NULL DEFAULT current_timestamp(),
  `token` text DEFAULT NULL,
  `estatus` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idusaurio`, `nombre`, `apellidos`, `correo`, `contrasena`, `telefono`, `direccion`, `sexo`, `fecha_nacimiento`, `fecha_alta`, `token`, `estatus`) VALUES
(1, 'Alejandro', 'Calixto Garcia', 'alejandrocalixto50@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '1343255346534', 'd2f2ffwef2332f23f', 'Hombre', '2022-10-27 05:00:00', '2022-10-14 22:52:18', NULL, 1),
(2, 'Alejandro', 'Calixto Garcia', 'alejandrocalixto50@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '1343255346534', 'd2f2ffwef2332f23f', 'Hombre', '2022-10-27 05:00:00', '2022-10-14 22:54:24', NULL, 1),
(3, 'Omer', 'Tapia rdg', 'alejandrocalixto50@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '1343255346534', 'd2f2ffwef2332f23f', 'Hombre', '2022-10-27 05:00:00', '2022-10-14 22:55:04', NULL, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `bi_categorias`
--
ALTER TABLE `bi_categorias`
  ADD PRIMARY KEY (`idcategoria`);

--
-- Indices de la tabla `bi_libros`
--
ALTER TABLE `bi_libros`
  ADD PRIMARY KEY (`idlibro`),
  ADD KEY `fk_idcategoria` (`idcategoria`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idusaurio`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `bi_categorias`
--
ALTER TABLE `bi_categorias`
  MODIFY `idcategoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `bi_libros`
--
ALTER TABLE `bi_libros`
  MODIFY `idlibro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idusaurio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `bi_libros`
--
ALTER TABLE `bi_libros`
  ADD CONSTRAINT `fk_idcategoria` FOREIGN KEY (`idcategoria`) REFERENCES `bi_categorias` (`idcategoria`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
