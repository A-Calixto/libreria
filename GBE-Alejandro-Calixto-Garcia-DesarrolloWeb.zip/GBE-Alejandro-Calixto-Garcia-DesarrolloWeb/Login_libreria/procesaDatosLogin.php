<?php

	/*
		Procesa los datos de sesion para el módulo libreria
	*/

	if ( $_POST ) {
		if ( $_POST['randomToken'] === $_POST['checkRandomToken'] ) {
			session_start();
			$_SESSION['user'] = $_POST['NuserL'];
			$_SESSION['userName'] = $_POST['userName'];

			header("Location:../app_libreria/");
			exit();
		}
			
	}


?>