<?php

include_once '../PHPMailer-master/PHPMailerAutoload.php';

class LoginModel{

	public function SaveRecord($pdo,$parameter){

		$parameter = explode('||', $parameter);
		$nombre = $parameter[0];
		$apellidos = $parameter[1];
		$correo = $parameter[2];
		$contrasena = $parameter[3];
		$telefono = $parameter[4];
		$direccion = $parameter[5];
		$sexo = $parameter[6];
		$fecha_nacimiento = $parameter[7];

		$sql = "INSERT into usuarios(nombre,apellidos,correo,contrasena,telefono,direccion,sexo,fecha_nacimiento) values(?,?,?,md5('$contrasena'),?,?,?,?);";

		$sentencia = $pdo->prepare( $sql );
		$res = $sentencia->execute( [ $nombre, $apellidos, $correo, $telefono, $direccion, $sexo, $fecha_nacimiento ] );
		return ($res === TRUE)?true:false;
	}

	public function CheckUser($pdo,$parameter){
		$parameter = explode('||', $parameter);
		$correo = $parameter[0];
		$password = $parameter[1];
		$sql = "SELECT * from usuarios where correo='$correo' and contrasena=md5('$password') and estatus='1'";
		$sentencia = $pdo->prepare( $sql );
		$sentencia->execute( );
		$count = $sentencia->rowCount();

		$registros = $sentencia->fetchAll(PDO::FETCH_OBJ);

		if ( $count > 0 ) {
			foreach( $registros as $datos ){
				$name = $datos->nombre;
			}

			$userData = array(
				'name' => $name,
				'count' => $count
			);
		} else{
			$userData = array(
				'name' => '',
				'count' => $count
			);
		}

		echo json_encode( $userData );
			

	}


}

?>