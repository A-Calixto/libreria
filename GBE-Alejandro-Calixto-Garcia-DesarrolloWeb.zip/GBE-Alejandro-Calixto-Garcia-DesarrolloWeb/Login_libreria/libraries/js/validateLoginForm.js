$(function(){

	var contentLoginForm = $("#contentLoginForm");
	var LoginForm = $("#LoginForm");
	var userL = $("#userL");
	var passL = $("#passL");
	var btnCheckIn = $("#btnCheckIn");

	btnCheckIn.on("click",registration);

	function registration(){
		var dataForm = loadTemplate('registrationForm').responseText;
		contentLoginForm.empty().append(dataForm);
		var registerForm = $("#registerForm");

		$("#sex").multiselect({
			maxHeight: 450,
		});

		$("#dateOfBirth").datepicker({
			autoclose:true,
			language:'es',
			format:"yyyy-mm-dd",
		});

		registerForm.bootstrapValidator({
			feedbackIcons:{
				valid: 'glyphicon glyphicon-ok',
				invalid: 'glyphicon glyphicon-remove',
				validating: 'glyphicon glyphicon-refresh'
			},
			fields: {

				userName:{
					validators:{
						notEmpty:{
							message:"Campo obligatorio"
						}
					}
				},
				surName : {
					validators:{
						notEmpty:{
							message:"Campo obligatorio"
						}
					}
				},
				email : {
					validators:{
						notEmpty:{
							message:"Campo obligatorio"
						},
						emailAddress:{
							message:"El correo no es valido"
						}
					}
				},

				password : {
					validators:{
						notEmpty:{
							message:"Campo obligatorio"
						}
					}
				},
				telephone : {
					validators:{
						notEmpty:{
							message:"Campo obligatorio"
						}
					}
				},
				address : {
					validators:{
						notEmpty:{
							message:"Campo obligatorio"
						}
					}
				},
				sex : {
					validators:{
						notEmpty:{
							message:"Campo obligatorio"
						}
					}
				},
				dateOfBirth : {
					validators:{
						notEmpty:{
							message:"Campo obligatorio"
						}
					}
				},				

			}
		}).on("submit",function(event,data){
			if (event.isDefaultPrevented()) {
				var userName = $("#userName").val();
				var surName = $("#surName").val();
				var email = $("#email").val();
				var password = $("#password").val();
				var telephone = $("#telephone").val();
				var address = $("#address").val();
				var sex = $("#sex").val();
				var dateOfBirth = $("#dateOfBirth").val();
				var params = userName+'||'+surName+'||'+email+'||'+password+'||'+telephone+'||'+address+'||'+sex+'||'+dateOfBirth;
				$.ajax({
					async: false,
					type:'POST',
					url:'./controllers/LoginController.php',
					dataType:'json',
					data: {
						casee:'saveRecord',
						parameter: params
					},
					success: function(data){
						console.log(data);
						if ( data==1 ) {
							alertBasic("Su registro fue exitoso","success");
							setTimeout( function(){ location.reload(); },2000 );
						} else{
							alertBasic("Error: No se pudo realizar su registro","error");
						}
					}
				});
			}
			else{
				event.preventDefault();
			}
		});
	}

	LoginForm.bootstrapValidator({
		feedbackIcons:{
			valid: 'glyphicon glyphicon-ok',
			invalid: 'glyphicon glyphicon-remove',
			validating: 'glyphicon glyphicon-refresh'
		},
		fields: {

			NuserL:{
				validators:{
					notEmpty:{
						message:"Campo obligatorio"
					}
				}
			},
			NpassL : {
				validators:{
					notEmpty:{
						message:"Campo obligatorio"
					}
				}
			},
			NselectTypeL : {
				validators:{
					notEmpty:{
						message:"Compo obligatorio"
					}
				}
			}

		}
	}).on("submit",function(event,data){
		if (event.isDefaultPrevented()) {
			//si todo sale bien
		} else{
			event.preventDefault();
			$("#btnLoginForm").attr('disabled',false);
				$.ajax({
					type:'POST',
					url:'./controllers/LoginController.php',
					dataType:'json',
					data: {
						casee:'checkUser',
						parameter: userL.val()+'||'+passL.val()
					},
					success: function(data){
						console.log(data['count']);
						if ( data['count'] > 0 ) {
							var tokenNumber = generateRandomToken();
							$("#randomToken").val(tokenNumber);
							$("#checkRandomToken").val(tokenNumber);
							// $("#userMail").val(mailUsu);
							$("#userName").val(data['name']);
							function generateRandomToken(){
								var length = 6;
								var token = "";
								for (var i=1; i <= length ; i++) {
									token = token+''+Math.floor( Math.random()*10 /* Returns a random integer from 0 to 9*/ );
								}
								return token;
							}

							document.getElementById("LoginForm").submit();

						} else alertBasic("tus datos son incorrectos o tu cuenta no está activada, favor de revisar tu correo y activar tu cuenta","error");

					}
				});		

		}
	});

});