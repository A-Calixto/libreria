function alertBasic(message,icon){
    sweetAlert("", message , icon);
}

function generateToken(){
	return $.ajax({
		async: false,
		type:'POST',
		url:'./controllers/LoginController.php',
		// dataType:'json',
		data: {
			casee:'generateToken',
			parameter: userType+'||'+userId+'||'+authorizationType
		},
		success: function(data){}
	});
}

// function generateTokenFPW(userType, userId, authorizationType){
// 	return $.ajax({
// 		async: false,
// 		type:'POST',
// 		url:'./controllers/LoginController.php',
// 		// dataType:'json',
// 		data: {
// 			casee:'generateTokenFPW',
// 			parameter: userType+'||'+userId+'||'+authorizationType
// 		},
// 		success: function(data){}
// 	});
// }

function checkIfThereIsActiveToken(userType, userId, authorizationType){
	return $.ajax({
		async: false,
		type:'POST',
		url:'./controllers/LoginController.php',
		dataType:'json',
		data: {
			casee:'checkIfThereIsActiveToken',
			parameter: userType+'||'+userId+'||'+authorizationType
		},
		success: function(data){}
	});
}

function checkToken(userType, userId, authorizationType, token){
	return $.ajax({
		async: false,
		type:'POST',
		url:'./controllers/LoginController.php',
		dataType:'json',
		data: {
			casee:'checkToken',
			parameter: userType+'||'+userId+'||'+authorizationType+'||'+token
		},
		success: function(data){}
	});
}

function showTwoFactorAuthenticationForm(userId){
	return $.ajax({
		async: false,
		type:'POST',
		url:'./views/twoFactorAuthenticationForm.php',
		success:function(data){
		}
	});
}

function lockedUserScreen(userId){
	return $.ajax({
		async: false,
		type:'POST',
		url:'./views/userBlocked.php',
		success:function(data){
		}
	});
}

function showChangePasswordForm(){
	return $.ajax({
		async: false,
		type:'POST',
		url:'./views/changeOfPassword.php',
		success:function(data){
		}
	});
}

function seveNewPassword(pass, userType, userId){
	return $.ajax({
		async: false,
		type:'POST',
		url:'./controllers/LoginController.php',
		dataType:'json',
		data: {
			casee:'seveNewPassword',
			parameter: userType+'||'+userId+'||'+pass
		},
		success: function(data){}
	});
}

function loadTemplate(template){
	return $.ajax({
		async: false,
		type:'POST',
		url:'./views/'+template+'.php',
		success:function(data){}
	});
}

function validateUserDateUserEmp( userId, userType ){
	return $.ajax({
		async: false,
		type:'POST',
		url:'./controllers/LoginController.php',
		dataType:'json',
		data: {
			casee:'validateUserDateUserEmp',
			parameter: userId+'||'+userType
		},
		success: function(data){}
	});
}



