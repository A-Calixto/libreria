<div class="form-group alert alert-warning">
	Favor de llenar el formulario para poder generar una nueva contraseña
</div>
<div class="form-group has-feedback">
	<span class="fa fa-user form-control-feedback"></span>
	<input class="form-control" height="35" type="text" name="userForgetPass" id="userForgetPass" value="" placeholder="Usuario" autocomplete="false" />
</div>

<!-- <div class="form-group has-feedback">
		<span class="fa fa-user form-control-feedback"></span>
		<input type="password" id="changePassword" name="changePassword" class="form-control">
	</div> -->

<div class="col-md-12 col-sm-12 col-xs-12 form-group">
	<label class="col-md-4 col-sm-4 col-xs-12">Perfil de usuario:</label>
	<div class="col-md-8 col-sm-8 col-xs-12">
		<select id="selectTypeForgetPass" name="selectTypeForgetPass">
			<option value="" selected="true"> < Seleccione el perfil de usuario > </option>
			<option value="userCSN"> Usuario de CSN </option>
			<option value="empresa"> Empresa </option>
			<option value="UsuEmp"> Usuario de Empresa </option>
		</select>
	</div>		
</div>

<div class="col-md-12 col-sm-12 col-xs-12 form-group">
	<button class="btn btn-primary" id="btnSendForgetPassForm">
		Validar datos
	</button>
</div>