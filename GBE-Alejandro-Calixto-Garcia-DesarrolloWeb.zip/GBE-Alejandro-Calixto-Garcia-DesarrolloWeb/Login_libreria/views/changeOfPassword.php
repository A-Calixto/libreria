<br><br><br><br><br><br>
<div class="form-group">
	
	<div class="form-group" id="btnGenerateNewToken">
		<h4>Crear contraseña</h4>
	</div>

	<p>Cree una contraseña, tome nota y guardela</p>
	

	<label>Nueva contraseña</label>
	<div class="form-group has-feedback">
		<span class="fa fa-eye form-control-feedback"></span>
		<input type="password" id="changePassword" name="changePassword" class="form-control">
	</div>
	<p>
		<small>
			La contraseña debe contener entre 8 y 16 caracteres. Puede usar a-z, A-Z, 0-9, @,-, _, !, #, $, %, & y. Debe usar al menos uno de cada uno de los siguientes caracteres:  <br>
			<ul>
				<li>Número</li>
				<li>Letra mayúscula</li>
				<li>Letra minúscula</li>
				<li>Carácter especial</li>
			</ul>
		</small>

	</p>
	

	<label>Confirmar contraseña</label>
	<div class="form-group has-feedback">
		<span class="fa fa-eye form-control-feedback"></span>
		<input type="password" id="changePasswordConfirm" name="changePasswordConfirm" class="form-control">
	</div>

	<div class="form-group">
		<button id="btnCreateNewPassword" class="btn btn-primary">Crear nueva contaseña</button>
	</div>

</div>