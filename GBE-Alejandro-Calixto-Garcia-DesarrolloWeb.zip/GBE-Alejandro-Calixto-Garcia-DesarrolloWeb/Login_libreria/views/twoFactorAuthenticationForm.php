<br><br><br><br><br><br>
<div class="form-group">
	
	<div class="form-group" id="btnGenerateNewToken">
		<a href="#">
			<span> Generar nuevo token </span>
		</a>
		
	</div>
	

	<div class="form-group">
		<input type="text" id="token" name="token" class="form-control" placeholder="Escribe codigo de verificación">
	</div>
	

	<div class="form-group">
			<button id="btnValidateToken" class="form-control btn btn-info btnnn" type="submit">
				Validar código
			</button>
		</div>
</div>