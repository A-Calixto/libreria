<style type="text/css">
	/*#Bloquear{
		background:#000000;
		width: 100%;
		height: 100%;
		filter:alpha(opacity=50);
		opacity:0.7;
		margin: 0px;
		position: absolute;
		left: 0px;
		top: 0px;
		right: 0px;
		z-index:1000;
		cursor: wait;  
		margin: 0px;
		padding: 0px;
	}*/

	#Bloquear
	{
		width: 100%;
		height: 100%;
		position:fixed;
		top:0px;
		left:0px;
		z-index:3200;
		filter:alpha(opacity=65);
		-moz-opacity:65;
		opacity:0.65;
		background:#999;
	}

	html
	{
		padding: 0;
		margin: 0;
		height: 100%;
		width: 100%;
	}

</style>

<div>
	<div id="Bloquear" class="alert alert-danger">
		<br><br><br><br><br><br><br><br><br><br><br><br>
			

		<center>
			<h1>
				Su usuario a sido bloqueado... <br> Favor de comunicase con Recursos Humanos de su empresa o con algún administrador del sistema o intentar más tarde...
			</h1>
			<span class="fa fa-lock fa-5x"></span>
		</center>
			
	</div>

</div>
	
	