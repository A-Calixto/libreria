<div class="form-group alert alert-warning">
	Favor de llenar el formulario correctamente
</div>

<form id="registerForm" autocomplete="off">
	<div class="form-group col-md-12 col-sm-12 col-xs-12">
		<label class="col-md-12 col-sm-12 col-xs-12">Nombre:</label>
		<div class="col-md-12 col-sm-12 col-xs-12">
			<input type="text" class="form-control" name="userName" id="userName">
		</div>
	</div>

	<div class="form-group col-md-12 col-sm-12 col-xs-12">
		<label class="col-md-12 col-sm-12 col-xs-12">Apellidos:</label>
		<div class="col-md-12 col-sm-12 col-xs-12">
			<input type="text" class="form-control" name="surName" id="surName">
		</div>
	</div>

	<div class="form-group col-md-12 col-sm-12 col-xs-12">
		<label class="col-md-12 col-sm-12 col-xs-12">Correo:</label>
		<div class="col-md-12 col-sm-12 col-xs-12">
			<input type="text" class="form-control" name="email" id="email">
		</div>
	</div>

	<div class="form-group col-md-12 col-sm-12 col-xs-12">
		<label class="col-md-12 col-sm-12 col-xs-12">Contraseña:</label>
		<div class="col-md-12 col-sm-12 col-xs-12">
			<input type="password" class="form-control" name="password" id="password">
		</div>
	</div>

	<div class="form-group col-md-12 col-sm-12 col-xs-12">
		<label class="col-md-12 col-sm-12 col-xs-12">Teléfono:</label>
		<div class="col-md-12 col-sm-12 col-xs-12">
			<input type="text" class="form-control" name="telephone" id="telephone">
		</div>
	</div>

	<div class="form-group col-md-12 col-sm-12 col-xs-12">
		<label class="col-md-12 col-sm-12 col-xs-12">Dirección:</label>
		<div class="col-md-12 col-sm-12 col-xs-12">
			<input type="text" class="form-control" name="address" id="address">
		</div>
	</div>

	<div class="form-group col-md-12 col-sm-12 col-xs-12">
		<label class="col-md-12 col-sm-12 col-xs-12">Sexo:</label>
		<div class="col-md-12 col-sm-12 col-xs-12">
			<select id="sex" name="sex">
				<option value=""> < Seleccione > </option>
				<option value="Hombre">Hombre</option>
				<option value="Mujer">Mujer</option>
			</select>
		</div>
	</div>

	<div class="form-group col-md-12 col-sm-12 col-xs-12">
		<label class="col-md-12 col-sm-12 col-xs-12">Fecha de nacimiento:</label>
		<div class="col-md-12 col-sm-12 col-xs-12">
			<input type="text" class="form-control" name="dateOfBirth" id="dateOfBirth" readonly="readonly">
		</div>
	</div>

	<div class="form-group col-md-12 col-sm-12 col-xs-12 col-md-offset-8">
			<button class="btn btn-primary">
				<i class="fa fa-save"></i> Guardar
			</button>
	</div>
</form>
	
