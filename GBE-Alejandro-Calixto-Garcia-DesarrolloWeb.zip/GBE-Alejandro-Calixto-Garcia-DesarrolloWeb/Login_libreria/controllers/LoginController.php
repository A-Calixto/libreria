<?php
include_once('../conexion.php');
include_once('../models/LoginModel.php');

ini_set('display_errors', 1);
error_reporting(E_ALL);

$loginObj = new LoginModel();

$case = $_POST['casee'];

switch ($case) {

	case 'saveRecord':
		$parameter = $_POST['parameter'];
		$datas = $loginObj->SaveRecord($pdo,$parameter);
		echo $datas;
		break;

	case 'checkUser':
		$parameter = $_POST['parameter'];
		$datas = $loginObj->CheckUser($pdo,$parameter);
		echo $datas;
		break;

	default:
		echo "No se encontro el tipo de acción";
		break;
}

?>