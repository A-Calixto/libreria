-- BASE DE DATOS
--drop table usuarios;
create table usuarios(
  idusaurio integer AUTO_INCREMENT not null,
  nombre varchar(50),
  apellidos varchar(50),
  correo varchar(30),
  contrasena text,
  telefono varchar(16),
  direccion varchar(200),
  sexo varchar(20),
  fecha_nacimiento timestamp,
  fecha_alta timestamp default now(),
  token text,
  estatus boolean default true,
  primary key (idusaurio)
);
