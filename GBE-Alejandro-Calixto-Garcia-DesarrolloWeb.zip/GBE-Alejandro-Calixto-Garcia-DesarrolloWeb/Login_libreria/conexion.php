<?php

	$servername = "localhost";
	$database = "db_libreria_calixto";
	$username = "root";
	$password = "";

	try{
		$pdo = new PDO('mysql:host='.$servername.';dbname='.$database,$username,$password);
		$pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	} catch(PDOException $exception) {
		exit($exception->getMessage());
	}

?>