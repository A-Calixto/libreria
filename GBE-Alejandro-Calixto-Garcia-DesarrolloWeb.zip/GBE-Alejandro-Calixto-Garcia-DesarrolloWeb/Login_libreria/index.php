<!DOCTYPE html>
<html>
<head>
	<title>Login empresas</title>

	<link rel="stylesheet" type="text/css" href="libraries/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="libraries/css/font-awesome.css<?php echo '?'.rand(1,1000); ?>">
	<link rel="stylesheet" type="text/css" href="libraries/css/bootstrap-multiselect.css">
	<link rel="stylesheet" type="text/css" href="libraries/css/bootstrap_datepicker.min.css">
	<link rel="stylesheet" type="text/css" href="libraries/sweetalert2/dist/sweetalert2.min.css">

	<link rel="stylesheet" type="text/css" href="libraries/css/bootstrapValidator.css">
	<link rel="stylesheet" type="text/css" href="libraries/css/style.css<?php echo '?'.rand(1,1000); ?>">

	<link href='//fonts.googleapis.com/css?family=Work+Sans:300,400,500' rel='stylesheet' type='text/css'>

	<script type="text/javascript" src="libraries/js/jquery-2.1.1.min.js"></script>
	<script type="text/javascript" src="libraries/js/encripData.js"></script>
	<script type="text/javascript" src="libraries/js/bootstrap.js"></script>
	<script type="text/javascript" src="libraries/js/bootstrap-multiselect.js"></script>

	<script type="text/javascript" src="libraries/js/bootstrap_datepicker.min.js"></script>
    <script type="text/javascript" src="libraries/js/bootstrap_datepicker.es.min.js"></script>

	<script src='https://www.google.com/recaptcha/api.js'></script>
	<script type="text/javascript" src="libraries/js/bootstrapValidator.js"></script>
	<script type="text/javascript" src="libraries/sweetalert2/dist/sweetalert2.min.js"></script>
	<script type="text/javascript" src="libraries/js/validateLoginForm.js<?php echo '?'.rand(1,1000); ?>"></script>
	<script type="text/javascript" src="libraries/js/functions.js<?php echo '?'.rand(1,1000); ?>"></script>

</head>

<body>
	<div class="content-image col-md-7 col-sm-7 col-xs-12">
		<center>
			<div class="head-login">
				<h1>IMAGEN</h1>
			</div>
		</center>
	</div>
	<div class="conten-login col-md-5 col-sm-5 col-xs-12">
		<center>
			<div class="head-login" style="width: 50%; height: 23%;">
				<!-- <img src="images/1.jpg"  class="img-responsive" alt="Responsive image"> -->
				<h1>LOGOTIPO</h1>
				
			</div>
		</center>

		<div id="contentLoginForm">
			<form id="LoginForm" class="form-login" method="post" action="procesaDatosLogin.php" autocomplete="off">

				<div class="form-group input-group input-group-lg">
					<span class="input-group-addon"><i class="fa fa-user"></i></span>
					<input class="form-control" height="35" type="text" name="NuserL" id="userL" value="" placeholder="Correo" autocomplete="false" />
				</div>

				<div class="form-group input-group input-group-lg">
					<span class="input-group-addon"><i class="fa fa-lock"></i></span>
					<input class="form-control" type="password" id="passL" name="NpassL" placeholder="Password">
				</div>

				<div class="form-group">
					<input class="form-control" type="hidden" id="userName" name="userName">
				</div>

				<div class="form-group">
					<input class="form-control" type="hidden" id="randomToken" name="randomToken">
				</div>

				<div class="form-group">
					<input class="form-control" type="hidden" id="checkRandomToken" name="checkRandomToken">
				</div>
				
				<br><br><br><br><br><br>

				<div class="form-group" id="btnCheckIn">
					<a href="#">
						<span> Registrarse </span>
					</a>
					
				</div>
				
				<div class="form-group">
					<button id="btnLoginForm" class="form-control btn btn-primary btnnn" type="submit">
						Iniciar sesion
					</button>
				</div>

				<div class="form-group conten-icon-socioNetworks">
					<ul>
						<li>
							<a href="">
								<img alt="Sígueme en Facebook" height="35" width="35" src="images/fb_icon_325x325.png"/>
							</a>
						</li>
						<li>
							<a href="">
								<img height="35" width="35" src="images/9-2-twitter-high-quality-png.png">
							</a>
						</li>
						<li>
							<a href="">
								<img height="35" width="35" src="images/Instagram-Icon.png">
							</a>
						</li>
					</ul>
						
				</div>

			</form>
		</div>
			
	</div>	

</body>
</html>