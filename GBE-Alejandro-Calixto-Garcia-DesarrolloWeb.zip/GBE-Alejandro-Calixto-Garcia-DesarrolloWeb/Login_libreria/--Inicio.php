<!DOCTYPE html>
<html>
<head>
	<title>Login empresas</title>

	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-multiselect.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrapValidator.css">
	<link rel="stylesheet" type="text/css" href="css/style.css<?php echo '?'.rand(1,1000); ?>">

	<link href='//fonts.googleapis.com/css?family=Work+Sans:300,400,500' rel='stylesheet' type='text/css'>

	<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
	<script type="text/javascript" src="js/encripData.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/bootstrap-multiselect.js"></script>
	<script src='https://www.google.com/recaptcha/api.js'></script>
	<script type="text/javascript" src="js/bootstrapValidator.js"></script>
	<script type="text/javascript" src="js/validateLoginForm.js<?php echo '?'.rand(1,1000); ?>"></script>

</head>
<body>
	<div class="content-image col-md-7 col-sm-7 col-xs-12">
		<center>
			<div class="head-login">
				<!-- <img src="images/nominas.png"  class="img-responsive" alt="Responsive image" > -->
				 <img src="images/logo.jpg"  class="img-responsive" alt="Responsive image" > 
			</div>
		</center>
	</div>
	<div class="conten-login col-md-5 col-sm-5 col-xs-12">
		<center>
			<div class="head-login" style="width: 50%; height: 23%;">
				<!-- <h1>Login</h1> -->
				<img src="images/csn_logoo.png"  class="img-responsive" alt="Responsive image">
				
			</div>
		</center>

		<!-- <br><br><br><br><br><br>
		<div class="form-group">
			<p> Se te envió un codigo de verificación al correo registrado en el sistema para que puedas validar tu acceso </p>
		
			<div class="form-group">
				<input type="text" id="token" name="token" class="form-control" placeholder="Escribe codigo de verificación">
			</div>
			

			<div class="form-group">
					<button id="btnValidateToken" class="form-control btn btn-info btnnn" type="submit">
						Validar código
					</button>
				</div>
		</div> -->
			

		

			

	</div>
		

</body>
</html>