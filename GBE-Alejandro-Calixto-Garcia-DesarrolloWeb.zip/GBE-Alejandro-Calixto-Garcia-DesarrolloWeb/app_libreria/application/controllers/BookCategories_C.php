<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class BookCategories_C extends CI_Controller {
	function index(){}

	function getCategoryLists(){
		echo $this->BookCategories_M->GetCategoryLists($_POST);
	}

	function saveCategory(){
		echo $this->BookCategories_M->SaveCategory($_POST);
	}

}