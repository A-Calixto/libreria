<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class MyLibrary_C extends CI_Controller{
	function index(){}

	function getMyBookList(){
		echo $this->MyLibrary_M->getMyBookList($_POST);
	}

}