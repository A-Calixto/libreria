<?php
// if ( ! defined('BASEPATH')) exit('No direct script access allowed');
defined('BASEPATH') OR exit('No direct script access allowed');

class LoadTemplate extends CI_Controller {

	public function index(){
		$template = $_POST['template'];
		$data = $this->load->view('templates/'.$template, '', true);
		print_r($data);
	}

}