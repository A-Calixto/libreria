<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class BookList_C extends CI_Controller {
	function index(){}

	function getBookLists(){
		echo $this->BookList_M->GetBookLists();
	}

	function getCategoryLists(){
		echo $this->BookList_M->GetCategoryLists($_POST);
	}

	function getTheBookList(){
		echo $this->BookList_M->GetTheBookList($_POST);
	}

	function saveBook(){
		echo $this->BookList_M->SaveBook($_POST);
	}

	function saveBookEdition(){
		echo $this->BookList_M->SaveBookEdition($_POST);
	}

	function updateBookImage(){
		echo $this->BookList_M->UpdateBookImage($_POST);
	}

	function deleteBook(){
		echo $this->BookList_M->DeleteBook($_POST);
	}
}