<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class GlobalController extends CI_Controller {
	function index(){}

	function getBetterBook(){
		echo $this->GlobalModel->GetBetterBook();
	}


}