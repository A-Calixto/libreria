<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- data table -->
    <link href="assets/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="assets/css/buttons.dataTables.min.css" rel="stylesheet">

    <link href="assets/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">

    <!-- bootstrap5 -->
    <link rel="stylesheet" href="assets/bootstrap5/css/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/bootstrap-multiselect.css">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/bootstrap_datepicker.min.css">

    <link rel="stylesheet" href="assets/css/myStylesForStarRating.css<?php echo '?'.rand(1,1000); ?>">

    <link rel="stylesheet" href="assets/css/estilos.css<?php echo '?'.rand(1,1000); ?>">


    <title>Biblioteca CSN</title>
</head>
<body id="body">

    <!--****** Nav header start *******-->
    <?php echo $header; ?>
    <!--******* Nav header end ********-->

    <div id="container" style="min-width: 100%;">

        <div class="pelicula-principal">
            <div class="contenedor"></div>
        </div>

        <div id="contenedorCarouselPeliculas"></div>

    </div>

     <!-- 
              -----------* GLOBAL MODAL WINDOW -----------*
              
              Please do not modify the modal window, it can be used for the whole system
        -->
        <!-- Modal Start -->
        <div class="modal fade" id="myModalGlobal" data-keyboard="false" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
              <div id="MG_header" class="modal-header">
                <div id="MG_Title"></div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div id="MG_body" class="modal-body row"></div>
              <div id="MG_footer" class="modal-footer"></div>
            </div>
          </div>
        </div>
        <!-- Modal End -->


    <!-- jquery -->
    <script type="text/javascript" src="assets/js/jquery.min.js"></script>
    <!-- Datatable -->
    <script src="assets/js/jquery.dataTables.min.js"></script>
    <script src="assets/js/plugins-init/datatables.init.js"></script>
    <script src="assets/js/dataTables.buttons.min.js"></script>
    <script src="assets/js/jszip.min.js"></script>
    <script src="assets/js/pdfmake.min.js"></script>
    <script src="assets/js/vfs_fonts.js"></script>
    <script src="assets/js/buttons.html5.min.js"></script>
    <script src="assets/js/buttons.print.min.js"></script>

    <!-- sweetalert2 -->
    <script src="assets/sweetalert2/dist/sweetalert2.min.js"></script>

    <!-- bootstrap -->
    <script src="assets/bootstrap5/js/bootstrap.bundle.min.js"></script>   
    <script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap-multiselect.js"></script>

    <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap_datepicker.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap_datepicker.es.min.js"></script>

    <script type="text/javascript" src="assets/js/library.js<?php echo '?'.rand(1,1000); ?>"></script>
    <script type="text/javascript" src="assets/js/functions.js"></script>
    <script src="assets/js/main.js"></script>

</body>
</html>