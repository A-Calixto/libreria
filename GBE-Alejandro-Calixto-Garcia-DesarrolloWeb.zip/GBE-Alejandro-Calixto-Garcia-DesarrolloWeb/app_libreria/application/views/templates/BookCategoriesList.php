<div class="container col-lg-12" style="width: 100%;
    margin: auto;">
    <div class="card my-5">
    <!-- <div class="card my-5" style="padding: 31px 16px 68px; background: #df353d; background-image: linear-gradient(to bottom,#ff2f39,#572c2c);"> -->
        <div class="card-header">
            <div class="row justify-content-between">
                <div class="col-md-4">
                    <h4 class="card-title" style="color:white;"> Alta de categorias </h4>
                </div>
                <div class="col-md-4" style="text-align: right;">
                    <button id="addCategories" class="botonDefault" style="" data-ope="addCategory">Agregar categoria</button>
                </div>
            </div>
                
        </div>
        <div class="card-body" style="">
            <div class="table-responsive">
                <table id="DTBookcategories" class="display" >
                    <thead>
                        <tr>
                            <th style="color:white;">Id</th>
                            <th style="color:white;">Nombre categoria</th>
                            <th style="color:white;">Descripción</th>
                            <th style="color:white;"> ------ </th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                    <tfoot></tfoot>
                </table>
            </div>

        </div>
    </div>
</div>





