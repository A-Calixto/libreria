<div class="container col-lg-12" style="width: 100%;
    margin: auto;">
    <!-- <div class="iq-card-transparent iq-card-block iq-card-stretch iq-card-height"> -->
    <div class="card my-5" >
        <div class="card-header">
            <div class="row justify-content-between">
                <div class="col-md-4">
                    <h4 class="card-title" style=""> Alta de libro </h4>
                </div>
                <div class="col-md-4" style="text-align: right;">

                    <button id="btnAddBook" data-bs-toggle="tooltip" class="botonDefault" style="" data-ope="addBook">Agregar nuevo libro</button>
                </div>
            </div>


                
        </div>
        <div class="card-body" style="">
            <div class="table-responsive">
                <table id="DTBookList" class="display" >
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Portada</th>
                            <th>Nombre</th>
                            <th>Autor</th>
                            <th>Aditorial</th>
                            <th>sinopsis</th>
                            <th>Categoria</th>
                            <th>Año</th>
                            <th>Fecha Alta</th>
                            <th>Estatus</th>
                            <th> -------------- </th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                    <tfoot></tfoot>
                </table>
            </div>

        </div>
    </div>
</div>