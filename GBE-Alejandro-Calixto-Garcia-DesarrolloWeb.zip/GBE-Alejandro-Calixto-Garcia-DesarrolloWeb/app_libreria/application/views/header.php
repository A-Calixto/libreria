<header>
    <?php
        // print_r( $_SESSION );
    ?>
    <div class="contenedor">
        <h2 class="logotipo">LOGOTIPO</h2>
        <marquee width=450 height=60 style="border:black .1px " SCROLLDELAY="1" SCROLLAMOUNT="1">
                <div class="" style="color:red; font-family: 'Netflix Sans','Helvetica Neue',Helvetica,Arial,sans-serif; font-weight: bold; font-size: 40px;"> <?php echo "BIENVENIDO: ". $_SESSION['userName']; ?> </div>
              </marquee>

        <nav id="menu" class="">
            <ul class="nav">
                <li class="drop-down"><a href="#" id="home" class="activo">Inicio</a></li>
                <!-- <li class="drop-down"><a href="#">Categorias</a>
                    <ul id="menu_categoryContainer"></ul>
                </li> -->
                
                <li>
                    <a href="">Altas</a>
                    <ul>
                        <li>
                            <a href="#" id="bookCategories" data-ope="BookCategoriesList">Alta de categorias</a>
                        </li>
                        <li>
                            <a href="#" id="bookList" data-ope="BookList">Alta de libros</a>
                        </li>
                    </ul>
                </li>

                <li>
                    <a href="<?php echo $_SERVER['PHP_SELF']; ?>?action_code=close">
                        Salir
                    </a>
                </li>

            </ul>
        </nav>
    </div>
</header>
<script type="text/javascript">
var userSession = {
		origin:"<?php echo $_SESSION['origin']?>",
		name:"<?php echo $_SESSION['name']?>",
		userId:<?php echo $_SESSION['userid']?>,
		userType:"<?php echo $_SESSION['userType']?>",
	};
Object.freeze(userSession);
</script>