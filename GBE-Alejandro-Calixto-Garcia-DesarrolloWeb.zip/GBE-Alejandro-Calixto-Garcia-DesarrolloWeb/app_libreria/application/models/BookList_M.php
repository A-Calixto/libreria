<?php
class BookList_M extends CI_Model{
	public function GetBookLists(){
		$arrayDatos = array();
		// $bookType = $post['bookType'];
		$sql = "SELECT * FROM bi_libros order by idlibro";
		$query = $this->db->query($sql);
		foreach( $query -> result_array() as $filas ){
			$datos = array_map('utf8_encode',$filas);
			array_push($arrayDatos,$datos);
		}

		echo '{"aaData":' .json_encode( $arrayDatos ). '}';
	}

	public function GetCategoryLists($post){
		$arrayDatos = array();
		$sql = "SELECT * from bi_categorias order by idcategoria";
		$query = $this->db->query($sql);
		foreach($query->result_array() as $filas){
			$datos = array_map('utf8_encode',$filas);
			array_push($arrayDatos,$datos);
		}

		echo json_encode( $arrayDatos );
	}

	public function GetTheBookList($post){
		$idType = $post['idType'];
		$id = $post['id'];
		$arrayDatos = array();
		$sql = ( $idType == 'idCategory' )
		?"SELECT * FROM bi_libros where idcategoria=$id and libro_digital='1' order by idlibro"
		:"SELECT * FROM bi_libros where idlibro=$id and libro_digital='1' order by idlibro";
		// echo $sql; 
		// die();
		$query = $this->db->query($sql);
		foreach( $query -> result_array() as $filas ){
			$datos = array_map('utf8_encode',$filas);
			array_push($arrayDatos,$datos);
		}

		echo json_encode( $arrayDatos );
	}

	public function SaveBook($post){
		$bookName = $post['bookName'];
		$bookCategory = $post['bookCategory'];
		$bookAuthor = $post['bookAuthor'];
		$editorialBook = $post['editorialBook'];
		$bookDescription = $post['bookDescription'];
		$yearOfTheBook = $post['yearOfTheBook'];

		$sql = "INSERT INTO bi_libros(nombre,autor,editorial,sinopsis,idcategoria,ano) values('$bookName','$bookAuthor','$editorialBook','$bookDescription',$bookCategory,$yearOfTheBook);";
		$queryInsert = $this->db->query($sql);

		$sqlLastId = "SELECT LAST_INSERT_ID();";
		$queryGetId = $this->db->query($sqlLastId);
		foreach( $queryGetId->row() as $valIdlibro ){
			$bookID = $valIdlibro;
		}
		if ( isset( $_FILES ) ) {
			if ( count($_FILES) > 0 ) {
				$bookImageFile = explode(".", $_FILES['bookImage']['name']);
				$bookImageExt = end($bookImageFile);
				$fileBookName = 'portada'.'_'.$bookID.'.'.$bookImageExt;
				
				BookList_M::saveBookImage($_FILES['bookImage'],$fileBookName);

				$sqlUpdate = "UPDATE bi_libros set portada='$fileBookName' where idlibro=$bookID;";
				$queryUpdate = $this->db->query($sqlUpdate);

			}		
		}
		return ( $queryInsert )?true:false;
	}

	public function SaveBookEdition($post){
		$bookId = $post['bookId'];
		$bookName = $post['bookName'];
		$bookCategory = $post['bookCategory'];
		$bookAuthor = $post['bookAuthor'];
		$editorialBook = $post['editorialBook'];
		$bookDescription = $post['bookDescription'];
		$yearOfTheBook = $post['yearOfTheBook'];

		$sqlUpdate = "UPDATE bi_libros set nombre='$bookName',autor='$bookAuthor',editorial='$editorialBook',sinopsis='$bookDescription',idcategoria=$bookCategory,ano=$yearOfTheBook where idlibro=$bookId;";
		$queryUpdate = $this->db->query($sqlUpdate);
		return ( $queryUpdate )?true:false;
	}


	function saveBookImage($files,$fileName){
			if(!empty($_FILES['bookImage']['tmp_name'])){
				$myFile = 'bookImage';
				$config['upload_path'] = './files/portadas';
				$config['file_name'] = $fileName;
				$config['allowed_types'] = "*";
				$config['overwrite'] = TRUE; //Overwrite files with the same name in the destination folder

				$this->load->library('upload');
				$this->upload->initialize($config);

				if (!$this->upload->do_upload($myFile)) {
				//*** ocurrio un error
				$data['uploadError'] = $this->upload->display_errors();
				echo $this->upload->display_errors();
				return;
				}

				$data['uploadSuccess'] = $this->upload->data();
			}

	}

	function saveBookPDF($files,$fileName){
			if(!empty($_FILES['bookPDF']['tmp_name'])){
				$myFile = 'bookPDF';
				$config['upload_path'] = './files/libros';
				$config['file_name'] = $fileName;
				$config['allowed_types'] = "jpg|png|pdf|jpeg";
				$config['overwrite'] = TRUE; //Overwrite files with the same name in the destination folder

				$this->load->library('upload');
				$this->upload->initialize($config);

				if (!$this->upload->do_upload($myFile)) {
				//*** ocurrio un error
				$data['uploadError'] = $this->upload->display_errors();
				echo $this->upload->display_errors();
				return;
				}

				$data['uploadSuccess'] = $this->upload->data();
			}

	}


	function UpdateBookImage($post){
			$bookID = $post['bookID'];
			if(!empty($_FILES['bookImage']['tmp_name'])){
				$bookImageFile = explode(".", $_FILES['bookImage']['name']);
				$bookImageExt = end($bookImageFile);
				$fileBookName = 'portada'.'_'.$bookID.'.'.$bookImageExt;

				$myFile = 'bookImage';
				$config['upload_path'] = './files/portadas';
				$config['file_name'] = $fileBookName;
				$config['allowed_types'] = "*";
				$config['overwrite'] = TRUE; //Overwrite files with the same name in the destination folder

				$this->load->library('upload');
				$this->upload->initialize($config);

				if (!$this->upload->do_upload($myFile)) {
				//*** ocurrio un error
				$data['uploadError'] = $this->upload->display_errors();
				echo $this->upload->display_errors();
				return;
				}

				$data['uploadSuccess'] = $this->upload->data();

				$sqlUpdate = "UPDATE bi_libros set portada='$fileBookName' where idlibro=$bookID;";
				$queryUpdate = $this->db->query($sqlUpdate);
				return ( $queryUpdate )?true:false;

			}
	}

	function DeleteBook($post){
		$bookId = $post['bookId'];
		$sql = "DELETE from bi_libros where idlibro=$bookId;";
		$query = $this->db->query($sql);
		return ( $query )?true:false;
	}

}
?>