<?php
class GlobalModel extends CI_Model{
	public function GetBetterBook(){
		$arrayDatos = array();
		$sql = "SELECT cal.idlibro,li.portada,li.nombre,li.nombre_digital,li.autor,li.descripcion,
			( select ROUND(AVG(pro.calificacion),1) from bi_calificaciones pro where pro.idlibro=cal.idlibro ) as promedio 
			from bi_calificaciones cal
			inner join bi_libros li on(li.idlibro=cal.idlibro)
			where cal.libro_digital='1'
			GROUP BY cal.idlibro, li.portada,li.nombre,li.nombre_digital,li.autor,li.descripcion ORDER BY promedio desc limit 1";
		$query = $this->db->query($sql);

		foreach($query->result_array() as $filas){
			$datos = array_map('utf8_encode',$filas);
			array_push($arrayDatos,$datos);
		}

		echo json_encode( $arrayDatos );

	}	

}
?>