<?php
class BookCategories_M extends CI_Model {
	public function GetCategoryLists($post){
		$arrayDatos = array();
		$sql = "SELECT * from bi_categorias order by idcategoria";
		$query = $this->db->query($sql);
		foreach($query->result_array() as $filas){
			$datos = array_map('utf8_encode',$filas);
			array_push($arrayDatos,$datos);
		}

		echo '{"aaData":' .json_encode( $arrayDatos ). '}';
	}

	public function SaveCategory($post){
		$casee = $post['casee'];
		$categoryName = $post['categoryName'];
		$categoryDescription = $post['categoryDescription'];
		// $userId = $post['userId'];
		$categoriId = $post['categoriId'];

		$sql = ( $casee === 'addCategory' )
		?"INSERT into bi_categorias(nombre_categoria,descripcion) values('$categoryName','$categoryDescription');"
		:"UPDATE bi_categorias set nombre_categoria='$categoryName',descripcion='$categoryDescription' where idcategoria=$categoriId;";
		$query = $this->db->query($sql);
		return ($query)?true:false;
	}





	// public function UploadDocumentProcess($post){
	// 	$idticket = $post['idticket'];
	// 	$sqlInsert = "INSERT INTO cai_documentos_procesos(idticket) values($idticket) returning iddocumento";
	// 	$resultQuery = $query = $this->db->query($sqlInsert);
	// 	foreach($query->row() as $valId){
	// 		$iddocumento = $valId;
	// 	}

	// 	if ( isset( $_FILES['fileElement'] ) ) {
	// 		// $idregister = $post['idregister'];
	// 		// $idelementopaso = $keyFile;
	// 		$nameDocumentOfficial = $_FILES['fileElement']['name'];
	// 		$File = explode(".", $_FILES['fileElement']['name']);
	// 		$ext = end($File);
	// 		$fileName = $idticket.'_'.$iddocumento.'.'.$ext;

	// 		if(!empty($_FILES['fileElement']['tmp_name'])){
	// 			$myFile = 'fileElement';
	// 			$config['upload_path'] = "./files/doc_procesos";
	// 			$config['file_name'] = $fileName;
	// 			// $config['allowed_types'] = "jpg|png|pdf|xml|jpeg";
	// 			$config['allowed_types'] = "*";
	// 			$config['overwrite'] = TRUE; //Overwrite files with the same name in the destination folder

	// 			$this->load->library('upload');
	// 			$this->upload->initialize($config);

	// 			if (!$this->upload->do_upload($myFile)) {
	// 			//*** ocurrio un error
	// 			$data['uploadError'] = $this->upload->display_errors();
	// 			echo $this->upload->display_errors();
	// 			return;
	// 			}
	// 			$data['uploadSuccess'] = $this->upload->data();
	// 		}
	// 		$sqlInsertFile = "UPDATE cai_documentos_procesos set nombre_documento='$nameDocumentOfficial', extension_file='$ext' where iddocumento=$iddocumento;";
	// 		$this->db->query($sqlInsertFile);
	// 	}
	// 	return ( $resultQuery )?true:false;
	// }



	public function DeleteBillDocument($post){
		$idTicket = $post['idTicket'];
		$idMinuta = $post['idMinuta'];
		$fileName = $post['fileName'];
		$queryDelete = "DELETE FROM cai_minutas where idticket=$idTicket and idminuta=$idMinuta";
		$link  = 'files/minutas/'.$fileName;
		unlink($link);
		return ( $this->db->query($queryDelete) )?true:false;
	}

	public function DeleteDocumentProceso($post){
		$idTicket = $post['idTicket'];
		$idDocumento = $post['idDocumento'];
		$fileName = $post['fileName'];
		$queryDelete = "DELETE FROM cai_documentos_procesos where idticket=$idTicket and iddocumento=$idDocumento";
		$this->db->query($queryDelete);
		$link  = 'files/doc_procesos/'.$fileName;
		unlink($link);
		return ( $this->db->query($queryDelete) )?true:false;
	}

}
?>