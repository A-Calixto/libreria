<?php

class MyLibrary_M extends CI_Model{
	public function getMyBookList($post){
		$arrayDatos = array();
		$userId = $post['userId'];
		$sql = "SELECT bi.*,li.* from bi_mi_biblioteca bi
				inner join bi_libros li on(bi.idlibro=li.idlibro)
				where usuario=$userId order by bi.idbiblioteca;";
		$query = $this->db->query($sql);
		foreach( $query->result_array() as $filas ){
			$datos = array_map('utf8_encode', $filas);
			array_push($arrayDatos,$datos);
		}
		echo json_encode( $arrayDatos );
	}
}

?>