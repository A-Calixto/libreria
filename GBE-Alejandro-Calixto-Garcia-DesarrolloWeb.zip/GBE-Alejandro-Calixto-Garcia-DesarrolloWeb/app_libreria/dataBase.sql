/*
    CREACIÓN DE LA BASE DE DATOS EN MYSQL
    PARA LA LIBRERIA GRUPO ORSAN
*/

/*
tablas para la base de datos
- bi_categorias
- bi_libros
*/


create table bi_categorias(
  idcategoria integer AUTO_INCREMENT not null,
  nombre_categoria text,
  descripcion text,
  fecha timestamp default now(),
  primary key (idcategoria)
);

create table bi_libros(
  idlibro integer AUTO_INCREMENT not null,
  portada text,
  nombre text,
  autor text,
  editorial text,
  sinopsis text,
  idcategoria integer,
  ano integer,
  pais text,
  idioma text,
  fecha_alta timestamp default now(),
  estatus boolean default true,
  primary key (idlibro)
);
alter table bi_libros
add constraint fk_idcategoria
foreign key (idcategoria)
references bi_categorias(idcategoria);


