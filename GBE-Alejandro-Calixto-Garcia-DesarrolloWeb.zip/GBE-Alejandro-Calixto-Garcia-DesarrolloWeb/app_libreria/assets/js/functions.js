/*/ 
    Script of the functions
    Author : Alejandro Calixto García
    Date   : October 14, 2022

    Script de funciones
    Autor   : Alejandro Calixto García
    Fecha   : 14 de Octubre del 2022
*/

function Tooltip(){
	var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
	var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
	  return new bootstrap.Tooltip(tooltipTriggerEl)
	})
}



function ScrollLeft(){
	var filaCarousel = $(this).parent().find('.contenedor-carousel');
	$(filaCarousel)[0].scrollLeft -= $(filaCarousel)[0].offsetWidth;
}

function ScrollRight(){
	var filaCarousel = $(this).parent().find('.contenedor-carousel');
	$(filaCarousel)[0].scrollLeft += $(filaCarousel)[0].offsetWidth;
}

function loadTemplate(template){
    return resAjax = $.ajax({
        async: false,
        url :'LoadTemplate',
        type:'POST',
        data:{template:template},
        success: function(data){
            return data;
        }
    });
}

function getCategoryLists(){
	return $.ajax({
		async: false,
		url : 'BookList_C/getCategoryLists',
		dataType:'json',
		success: function(data){}
	});
}

function getTheBookList(idType,id){
	return $.ajax({
		async: false,
		url : 'BookList_C/getTheBookList',
		type:'POST',
		dataType:'json',
		data:{idType:idType,id:id},
		success: function(data){}
	});
}

function getMyBookList(userId){
	return $.ajax({
		async: false,
		url : 'MyLibrary_C/getMyBookList',
		type:'POST',
		dataType:'json',
		data:{userId:userId},
		success: function(data){}
	});
}

function getBetterBook(){
	return $.ajax({
		async: false,
		url : 'GlobalController/getBetterBook',
		type:'POST',
		dataType:'json',
		// data:{},
		success: function(data){}
	});
}


function checkFavorite(bookId,userId){
	return $.ajax({
		async: false,
		type: 'POST',
		url : 'BookList_C/checkFavorite',
		dataType:'json',
		data:{bookId:bookId,userId:userId},
		success:function(data){}
	});
}

function checkLibrary(bookId,userId){
	return $.ajax({
		async: false,
		type: 'POST',
		url : 'BookList_C/checkLibrary',
		dataType:'json',
		data:{bookId:bookId,userId:userId},
		success:function(data){}
	});
}

function getGrade(bookId){
	return $.ajax({
		async: false,
		type: 'POST',
		url : 'BookList_C/getGrade',
		dataType:'json',
		data:{bookId:bookId},
		success:function(data){}
	});
}

function getRequestDetails(requestId){
	return $.ajax({
		async: false,
		type:'POST',
		url : 'LoanApplicationReport_C/getRequestDetails',
		dataType:'json',
		data:{requestId:requestId},
		success: function(data){}
	});
}

function checkUser(){
	return $.ajax({
		async: false,
		type:'POST',
		url :'LoanApplicationReport_C/checkUser',
		// dataType:'json',
		data:{
			user:$("#userCheck").val(),
			password:$("#passCheck").val()
		},
		success : function(data){}
	});
}

function booksToGrade(userId){
	return $.ajax({
		async: false,
		type:'POST',
		url :'LoanApplication_C/booksToGrade',
		// dataType:'json',
		data:{
			userId:userId
		},
		success : function(data){}
	});
}


function alertBasic(message,icon){
    sweetAlert("", message , icon);
}



var paramsDataTableDefaults = {
    lengthDT : {lengthMenu : [[ 10, 25, 50, -1 ],[ '10 filas', '25 filas', '50 filas', 'Todos' ]]},
    languaje_table : {
            sProcessing:     "Procesando...",
                sLengthMenu:     "Mostrar _MENU_ registros",
                sZeroRecords:    "No se encontraron resultados",
                sEmptyTable:     "Ningún dato disponible en esta tabla",
                sInfo:           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                sInfoEmpty:      "Mostrando registros del 0 al 0 de un total de 0 registros",
                sInfoFiltered:   "(filtrado de un total de _MAX_ registros)",
                sInfoPostFix:    "",
                sSearch:         "Buscar:",
                sUrl:            "",
                sInfoThousands:  ",",
                sLoadingRecords: "Cargando...",
                oPaginate: {
                    sFirst:    "Primero",
                    sLast:     "Último",
                    sNext:     "Siguiente",
                    sPrevious: "Anterior"
                },
                oAria: {
                    sSortAscending:  ": Activar para ordenar la columna de manera ascendente",
                    sSortDescending: ": Activar para ordenar la columna de manera descendente"
                }
        }

}





