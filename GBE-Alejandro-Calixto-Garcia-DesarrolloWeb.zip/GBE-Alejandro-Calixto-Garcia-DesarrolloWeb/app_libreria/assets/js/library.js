$(function(){

	var contentTemplates = $("#container");
	var bookCategories = $("#bookCategories");
	var bookList = $("#bookList");

	$("#body").off("click","#home");
	$("#body").on("click","#home",reloadPage);
	$("#body").off("click","#bookCategories");
	$("#body").on("click","#bookCategories",BookCategories);
	$("#body").off("click","#bookList");
	$("#body").on("click","#bookList",BookList);

	function reloadPage(){
		location.reload();
	}

	fillTheCategoryMenu();
	function fillTheCategoryMenu(){
		$("#menu_categoryContainer").empty();
		$.each( getCategoryLists().responseJSON, function(ind,val){
			var listItem = '<li><a href="#contenedorCategorias'+val.idcategoria+'"> '+val.nombre_categoria+' </a></li>';
			$("#menu_categoryContainer").append( listItem );
		} );
	}

	BookList();

// ************************* SOLICITUD DE PRESTAMOS **************************

// ************************* REPORTE DE SOLICITUDES DE PRÉSTAMOS **************************

// ************************* MENU ALTA DE CATEGORIAS **************************

	function BookCategories(){
		var template = bookCategories.data('ope');
		var data = loadTemplate(template).responseText;
		contentTemplates.empty();
		contentTemplates.append(data);
		var btnAddCategories = $("#addCategories");
		btnAddCategories.off("click");
		btnAddCategories.on("click",this,addCategories);

		function addCategories(){
			var casee = $(this).data('ope').split('_');
			if ( casee[0] === 'editCategory' ) {
				var categoriId = casee[1];
				var inputCategoryName = casee[2];
				var inputCategoryDescription = casee[3];
			} else{
				var categoriId = "";
				var inputCategoryName = "";
				var inputCategoryDescription = "";
			}
			$("#MG_Title").empty();
			$("#MG_body").empty();
			$("#MG_footer").empty();
			$("#MG_Title").append('<h2>Alta de categorias<h2>');
			$("#MG_body").append('<div class="mb-3"><label for="recipient-name" class="col-form-label">Nombre de la categoria:</label><input type="text" class="form-control" id="categoryName" name="categoryName" value='+inputCategoryName+'></div><div class="mb-3"><label for="message-text" class="col-form-label">Descripción:</label><textarea class="form-control" id="categoryDescription" rows="4" name="categoryDescription" >'+inputCategoryDescription+'</textarea></div>');
			$("#MG_footer").append('<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancelar</button><button type="button" id="btnSaveCategory" class="btn btn-primary">Guardar</button>');
			$("#myModalGlobal").modal('show');

			$("#btnSaveCategory").off("click");
			$("#btnSaveCategory").on("click",this,saveCategory);

			function saveCategory(){
				if ( $("#categoryName").val() != "" ) {
					swal({
						title: '¿Deseas guardar la información?',
						text: "",
						type: 'warning',
						showCancelButton: !0,
						confirmButtonColor: '#3085d6',
						cancelButtonColor: '#d33',
						confirmButtonText: 'Si',
						cancelButtonText:'No'
						// closeOnConfirm: !1
					}).then((result) => {
						if (result!="undefined") {
							if (result.value) {
								$.ajax({
									type:'POST',
									url : 'BookCategories_C/saveCategory',
									data:{
										casee:casee[0],
										categoryName:$("#categoryName").val(),
										categoryDescription:$("#categoryDescription").val(),
										// userId:userSession.userId,
										categoriId:categoriId
									},
									success: function(data){
										$("#myModalGlobal").modal('hide');
										if (data==1) {
											$("#DTBookcategories").dataTable()._fnAjaxUpdate();
											alertBasic("La operación se realizó con exíto","success");
										} else{
											alertBasic("No se pudo ejecutar la operación","error");
										}
									}
								});
							}
						}
					})
				} else { alertBasic("Favor de poner el nombre de la categoria","warning"); }
					
			}		

		}

		$("#DTBookcategories").dataTable({
			dom:'Bfrtip',
			lengthMenu : paramsDataTableDefaults.lengthDT.lengthMenu,
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			],
			bAutoWidth: true,
			bFilter: true,
			bInfo: true,
			bLengthChange: true,
			bPaginate: true,
			bSort: true,
			iDisplayLength:100,
			bDestroy: true,
			bProcessing: true,
			ordering: false,
			oLanguage : paramsDataTableDefaults.languaje_table,
			ajax: {
				url:'BookCategories_C/getCategoryLists',
				type:'POST'
			},
			aoColumnDefs : [
				{
					aTargets: [0,1,3],
					sClass: 'text-center',
					sWidth: '1em'
				},
				{
					aTargets: [0],
					bSortable: false,
					mData: function(data){
						return data.idcategoria;
					}
				},
				{
					aTargets: [1],
					bSortable: false,
					mData: function(data){
						return data.nombre_categoria;
					}
				},
				{
					aTargets: [2],
					bSortable: false,
					mData: function(data){
						return data.descripcion;
					}
				},
				{
					aTargets: [3],
					bSortable: false,
					mData: function(data){
						return '<button class="btn btn-primary shadow btn-xs sharp mr-1 editCategory " data-ope="editCategory_'+data.idcategoria+'_'+data.nombre_categoria+'_'+data.descripcion+'" data-toggle="tooltip" data-placement="top" data-original-title="Actualizar"> <i class="fas fa-sync-alt"></i></button>';
					}
				}					
					 
			],
			fnRowCallback(nRow,aData,iDisplayIndex){

			},
			drawCallback(settings){
				Tooltip();

				
			}
		});

		$("#DTBookcategories").off("click",".editCategory");
		$("#DTBookcategories").on("click",".editCategory",this,addCategories);

	}


// ************************* SCRIP PARA LA ALTA DE LIBROS **************************
	function BookList(){
		var template = bookList.data('ope');
		var data = loadTemplate(template).responseText;
		contentTemplates.empty();
		contentTemplates.append(data);
		var btnAddBook = $("#btnAddBook");
		var bookType = $("#bookType");
		btnAddBook.off("click");
		btnAddBook.on("click",this,addBook);
		showTableBookList();
		Tooltip();

		function editBook(){

			var bookData = $(this).data('ope').split("_");
			console.log(bookData);
			var addBookForm = ('<div class="mb-3"><label class="col-form-label">Nombre del libro:</label><input type="text" class="form-control" id="bookName" name="bookName"></div>   <div class="mb-3"><label class="col-form-label">Autor:</label><input type="text" class="form-control" id="bookAuthor" name="bookAuthor"></div>   <div class="mb-3"><label class="col-form-label">Editorial:</label><input type="text" class="form-control" id="editorialBook" name="editorialBook"></div>   <div class="mb-3"><label class="col-form-label">Sinopsis:</label><textarea class="form-control" id="bookDescription" name="bookDescription" rows="4"></textarea></div>   <div class="mb-3"><label class="col-form-label">Categoria:</label><select id="bookCategory" class="form-select form-select-sm"></select></div>   <div class="mb-3"><label class="col-form-label">Año:</label><input type="text" id="yearOfTheBook" name="yearOfTheBook" class="datepicker form-control input-sm" data-date-format="dd/mm/yyyy" readonly=""></div>     </div>');

			$("#MG_Title").empty();
			$("#MG_body").empty();
			$("#MG_footer").empty();
			$("#MG_Title").append('<h2>Editar de libro<h2>');
			$("#MG_body").append(addBookForm);
			$("#MG_footer").append('<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancelar</button><button type="button" id="btnSaveBook" class="btn btn-primary">Guardar</button>');
			$("#myModalGlobal").modal('show');
			$("#bookCategory").empty();
			$("#bookCategory").append('<option value=""> < Seleccione > </option>');
			$.each( getCategoryLists().responseJSON, function(ind,val){
				$("#bookCategory").append('<option value="'+val.idcategoria+'">'+val.nombre_categoria+'</option>');
			} );

			var bookName = $("#bookName");
			var bookCategory = $("#bookCategory");
			var bookAuthor = $("#bookAuthor");
			var editorialBook = $("#editorialBook");
			var bookDescription = $("#bookDescription");
			var yearOfTheBook = $("#yearOfTheBook");
			var digitalBook = $("#digitalBook");
			var bookImage = $("#bookImage");

			$("#yearOfTheBook").datepicker({
				autoclose:true,
				language:'es',
				format:"yyyy",
				startView:"years",
				minViewMode:"years",
			});


			bookName.val( bookData[1] );
			bookAuthor.val( bookData[2] );
			editorialBook.val( bookData[3] );
			bookDescription.val( bookData[4] );
			$('#bookCategory option[value="'+bookData[5]+'"]').attr('selected',true);
			yearOfTheBook.val( bookData[6] );

			$("#btnSaveBook").off("click");
			$("#btnSaveBook").on("click",this,saveBookEdition);

			function validateEditForm(){
				var flag = true;
				if ( bookName.val() == "" ) flag = false;
				if ( bookCategory.val() == "" ) flag = false;
				if ( bookAuthor.val() == "" ) flag = false;
				if ( editorialBook.val() == "" ) flag = false;
				if ( bookDescription.val() == "" ) flag = false;
				if ( yearOfTheBook.val() == "" ) flag = false;
				return flag;
			}

			function saveBookEdition(){
				var allGood = validateEditForm();
				if ( allGood ) {
					var contentData = new FormData();
					contentData.append('bookId',bookData[0]);
					contentData.append('bookName',bookName.val());
					contentData.append('bookCategory',bookCategory.val());
					contentData.append('bookAuthor',bookAuthor.val());
					contentData.append('editorialBook',editorialBook.val());
					contentData.append('bookDescription',bookDescription.val());
					contentData.append('yearOfTheBook',yearOfTheBook.val());


					swal({
						title: '¿Deseas guardar los cambios?',
						text: "",
						type: 'warning',
						showCancelButton: !0,
						confirmButtonColor: '#3085d6',
						cancelButtonColor: '#d33',
						confirmButtonText: 'Si',
						cancelButtonText:'No'
						// closeOnConfirm: !1
					}).then((result) => {
						if (result!="undefined") {
							if (result.value) {
								$.ajax({
									type:'POST',
									url : 'BookList_C/saveBookEdition',
									data:contentData,
									processData:false,
									contentType: false,
									success: function(data){
										$("#myModalGlobal").modal('hide');
										if (data==1) {
											$("#DTBookList").dataTable()._fnAjaxUpdate();
											alertBasic("La operación se realizó con exíto","success");
										} else{
											alertBasic("No se pudo ejecutar la operación","error");
										}
									}
								});
							}
						}
					})
				} else { alertBasic("Favor de poner el nombre de la categoria","warning"); }
					
			}


		}

		function addBook(){
			var casee = $(this).data('ope').split('_');
			if ( casee[0] === 'editBook' ) {
				var bookId = casee[1];
				var inputBookName = casee[2];
				var inputBookDescription = casee[3];
			} else{
				var bookId = "";
				var inputBookName = "";
				var inputBookDescription = "";
			}

			var addBookForm = ('<div class="mb-3"><label class="col-form-label">Nombre del libro:</label><input type="text" class="form-control" id="bookName" name="bookName"></div>   <div class="mb-3"><label class="col-form-label">Autor:</label><input type="text" class="form-control" id="bookAuthor" name="bookAuthor"></div>   <div class="mb-3"><label class="col-form-label">Editorial:</label><input type="text" class="form-control" id="editorialBook" name="editorialBook"></div>   <div class="mb-3"><label class="col-form-label">Sinopsis:</label><textarea class="form-control" id="bookDescription" name="bookDescription" rows="4"></textarea></div>   <div class="mb-3"><label class="col-form-label">Categoria:</label><select id="bookCategory" class="form-select form-select-sm"></select></div>   <div class="mb-3"><label class="col-form-label">Año:</label><input type="text" id="yearOfTheBook" name="yearOfTheBook" class="datepicker form-control input-sm" data-date-format="dd/mm/yyyy" readonly=""></div>   <div id="formDigital"> <div class="mb-3"><label class="col-form-label">Imagen de la portada: Formatos(jpeg,jpg,png)</label><input type="file" class="form-control" id="bookImage" name="bookImage"></div>  </div>');

			$("#MG_Title").empty();
			$("#MG_body").empty();
			$("#MG_footer").empty();
			$("#MG_Title").append('<h2>Alta de nuevo libro<h2>');
			$("#MG_body").append(addBookForm);
			$("#MG_footer").append('<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancelar</button><button type="button" id="btnSaveBook" class="btn btn-primary">Guardar</button>');
			$("#myModalGlobal").modal('show');
			$("#bookCategory").empty();
			$("#bookCategory").append('<option value=""> < Seleccione > </option>');
			$.each( getCategoryLists().responseJSON, function(ind,val){
				$("#bookCategory").append('<option value="'+val.idcategoria+'">'+val.nombre_categoria+'</option>');
			} );

			var bookName = $("#bookName");
			var bookCategory = $("#bookCategory");
			var bookAuthor = $("#bookAuthor");
			var editorialBook = $("#editorialBook");
			var bookDescription = $("#bookDescription");
			var yearOfTheBook = $("#yearOfTheBook");
			var digitalBook = $("#digitalBook");
			var bookImage = $("#bookImage");

			$("#yearOfTheBook").datepicker({
				autoclose:true,
				language:'es',
				format:"yyyy",
				startView:"years",
				minViewMode:"years",
			});

			$("#btnSaveBook").off("click");
			$("#btnSaveBook").on("click",this,saveBook);

			function validateAddForm(){
				var flag = true;
				if ( bookName.val() == "" ) flag = false;
				if ( bookCategory.val() == "" ) flag = false;
				if ( bookAuthor.val() == "" ) flag = false;
				if ( editorialBook.val() == "" ) flag = false;
				if ( bookDescription.val() == "" ) flag = false;
				if ( yearOfTheBook.val() == "" ) flag = false;
				var elementBookImage = $('#bookImage')[0];
				if ( elementBookImage.files.length == 0 ) {
					flag = false;
				}
				return flag;
			}

			function saveBook(){
				var allGood = validateAddForm();
				if ( allGood ) {

					var contentData = new FormData();
					contentData.append('casee',casee[0]);
					contentData.append('bookName',bookName.val());
					contentData.append('bookCategory',bookCategory.val());
					contentData.append('bookAuthor',bookAuthor.val());
					contentData.append('editorialBook',editorialBook.val());
					contentData.append('bookDescription',bookDescription.val());
					contentData.append('yearOfTheBook',yearOfTheBook.val());
					var isDigital = true;
					var elementBookImage = $('#bookImage')[0];
					contentData.append('bookImage',elementBookImage.files[0]);
					contentData.append('isDigital',isDigital);

					swal({
						title: '¿Deseas guardar la información?',
						text: "",
						type: 'warning',
						showCancelButton: !0,
						confirmButtonColor: '#3085d6',
						cancelButtonColor: '#d33',
						confirmButtonText: 'Si',
						cancelButtonText:'No'
						// closeOnConfirm: !1
					}).then((result) => {
						if (result!="undefined") {
							if (result.value) {
								$.ajax({
									type:'POST',
									url : 'BookList_C/saveBook',
									data:contentData,
									processData:false,
									contentType: false,
									success: function(data){
										$("#myModalGlobal").modal('hide');
										if (data==1) {
											$("#DTBookList").dataTable()._fnAjaxUpdate();
											alertBasic("La operación se realizó con exíto","success");
										} else{
											alertBasic("No se pudo ejecutar la operación","error");
										}
									}
								});
							}
						}
					})
				} else { alertBasic("Favor de poner el nombre de la categoria","warning"); }
					
			}		

		}

		function deleteBook(){
			var bookId = $(this).data('ope');
			swal({
				title: '¿Quieres eliminar este libro?',
				text: "",
				type: 'warning',
				showCancelButton: !0,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: 'Si',
				cancelButtonText:'No'
				// closeOnConfirm: !1
			}).then((result) => {
				if (result!="undefined") {
					if (result.value) {
						$.ajax({
							type:'POST',
							url : 'BookList_C/deleteBook',
							data:{bookId:bookId},
							success: function(data){
								if (data==1) {
									$("#DTBookList").dataTable()._fnAjaxUpdate();
									alertBasic("La operación se realizó con exíto","success");
								} else{
									alertBasic("No se pudo eliminar el registro","error");
								}
							}
						});
					}
				}
			})
		}

		function showTableBookList(){
			$("#DTBookList").dataTable({
				dom:'Bfrtip',
				lengthMenu : paramsDataTableDefaults.lengthDT.lengthMenu,
				buttons: [
					'excel', 'pdf', 'print'
				],
				bAutoWidth: true,
				bFilter: true,
				bInfo: true,
				bLengthChange: true,
				bPaginate: true,
				bSort: true,
				iDisplayLength:100,
				bDestroy: true,
				bProcessing: true,
				ordering: false,
				oLanguage : paramsDataTableDefaults.languaje_table,
				ajax: {
					url:'BookList_C/getBookLists',
					type:'POST',
					// data:{bookType:bookType}
				},
				aoColumnDefs : [
					{
						aTargets: [0,1,6,7,8,9],
						sClass: 'text-center',
						sWidth: '1em'
					},
					{
						aTargets: [0],
						bSortable: false,
						mData: function(data){
							return data.idlibro;
						}
					},
					{
						aTargets: [1],
						bSortable: false,
						mData: function(data){
							// return data.portada;
							return '<input type="file" id="inputFile'+data.idlibro+'" style="display:none;"> <a id="" class="updateBookImage" data-ope="'+data.idlibro+'" style="cursor:pointer;" data-bs-toggle="tooltip" title="Reemplazar portada"> <img class="img-fluid rounded" src="files/portadas/'+data.portada+'" alt=""> </a>';
						}
					},
					{
						aTargets: [2],
						bSortable: false,
						mData: function(data){
							return data.nombre;
						}
					},
					{
						aTargets: [3],
						bSortable: false,
						mData: function(data){
							return data.autor;
						}
					},
					{
						aTargets: [4],
						bSortable: false,
						mData: function(data){
							return data.editorial;
						}
					},
					{
						aTargets: [5],
						bSortable: false,
						mData: function(data){
							return data.sinopsis;
						}
					},
					{
						aTargets: [6],
						bSortable: false,
						mData: function(data){
							return data.idcategoria;
						}
					},
					{
						aTargets: [7],
						bSortable: false,
						mData: function(data){
							return data.ano;
						}
					},
					{
						aTargets: [8],
						bSortable: false,
						mData: function(data){
							var fecha_alta = data.fecha_alta.split(" ");
							return fecha_alta[0];
						}
					},
					{
						aTargets: [9],
						bSortable: false,
						mData: function(data){
							return data.estatus;
						}
					},
					{
						aTargets: [10],
						bSortable: false,
						mData: function(data){
							var parameter = ''+data.idlibro+'_'+data.nombre+'_'+data.autor+'_'+data.editorial+'_'+data.sinopsis+'_'+data.idcategoria+'_'+data.ano+'';
							var btnUpdate = '<button class="btn btn-primary shadow btn-sm sharp mr-1 editBook " data-ope="'+parameter+'" data-bs-toggle="tooltip" title="Actualizar"> <i class="fas fa-sync-alt"></i></button>';
							var btnDelete = '<button class="btn btn-danger shadow btn-sm sharp mr-1 deleteBook " data-ope="'+data.idlibro+'" data-bs-toggle="tooltip" title="Eliminar"> <i class="fa fa-trash-o"></i></button>';
							return btnUpdate+' '+btnDelete;
						}
					}					
						 
				],
				fnRowCallback(nRow,aData,iDisplayIndex){
				},
				drawCallback(settings){
					Tooltip();
				}
			});	
		}
		
		$("#DTBookList").off("click",".updateBookImage");	
		$("#DTBookList").on("click",".updateBookImage",this,updateBookImage);

		$("#DTBookList").off("click",".editBook");	
		$("#DTBookList").on("click",".editBook",this,editBook);

		$("#DTBookList").off("click",".deleteBook");	
		$("#DTBookList").on("click",".deleteBook",this,deleteBook);

		// $(".editCategory").off("click");
		// $("#DTBookcategories").on("click",".editCategory",this,addCategories);

		function updateBookImage(){
			var id = $(this).data('ope');
			swal({
				title: '¿Quieres actualizar la portada de este libro?',
				text: "",
				type: 'warning',
				showCancelButton: !0,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: 'Si',
				cancelButtonText:'No'
				// closeOnConfirm: !1
			}).then((result) => {
				if (result!="undefined") {
					if (result.value) {
						$('#inputFile'+id).off("change");
						$('#inputFile'+id).on("change",updateImage);
						$('#inputFile'+id).click();
						function updateImage(){
							var contentData = new FormData();
							var elementBookImage = $('#inputFile'+id)[0];
							contentData.append('bookImage',elementBookImage.files[0]);
							contentData.append('bookID',id);
							$.ajax({
								type:'POST',
								url : 'BookList_C/updateBookImage',
								data:contentData,
								processData:false,
								contentType: false,
								success: function(data){
									if (data==1) {
										$("#DTBookList").dataTable()._fnAjaxUpdate();
										alertBasic("La portada se actualizó con exíto","success");
									} else{
										alertBasic("No se pudo ejecutar la operación","error");
									}
								}
							});

						}
							
					}
				}
			})

		}

	}

});